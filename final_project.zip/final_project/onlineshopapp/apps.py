from django.apps import AppConfig


class onlineshopappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'onlineshopapp'
